import os

def lambda_handler(event, context):
    print("Hello TinhDH")
    return "{} from Lambda!".format(os.environ['greeting'])
